//
//  Signup.swift
//  Route
//
//  Created by Ramesh Siddanavar on 3/22/18.
//  Copyright © 2018 Ramesh Siddanavar. All rights reserved.
//

import UIKit

class Signup: UIViewController {

    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet var profileStackView: UIStackView!
    @IBOutlet var pinStackView: UIStackView!
    @IBOutlet var passStackView: UIStackView!
    
    @IBOutlet weak var imgView: UIImageView!
  //  @IBOutlet weak var imgV: UIImageView!
    
    @IBOutlet var _first: UITextField!
    @IBOutlet var _last: UITextField!
    @IBOutlet var _dob: UITextField!
//    @IBOutlet var _gender: UITextField!
    @IBOutlet var _email: UITextField!
    @IBOutlet var _updateButton: UIButton!
    
    @IBOutlet var _mobile: UITextField!
    @IBOutlet var _password: UITextField!
    @IBOutlet var _loginButton: UIButton!
    
    @IBOutlet var _newPin: UITextField!
    @IBOutlet var _confirmPin: UITextField!
    @IBOutlet var _saveButton: UIButton!
    
    @IBOutlet var errorText: UILabel!
    var mobile = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
          imgView.backgroundColor = UIColor.init(red: 220.0 / 255.0, green: 109.0 / 255.0, blue: 68.0 / 255.0, alpha: 1.0)
          imgView.backgroundColor = UIColor.init(red: 217.0 / 255.0, green: 68.0 / 255.0, blue: 78.0 / 255.0, alpha: 1.0)
        
        // Do any additional setup after loading the view.
         self.hideKeyboardWhenTappedAround()
        passStackView.isHidden = true
        pinStackView.isHidden = true
        profileStackView.isHidden = true
    }
    
    // Keyboard Hiding...
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(LoginViewControllerr.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
     //   stackView.isHidden = false
    //    pinStackView.isHidden = true
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func loginButtonPress(_ sender: Any) {
        let username = _mobile.text
      //  let password = _password.text
        
        if(username == "") {
            return
        }
        self.mobile = username!
        //     self.coreLogin(username: username!, password: password!)
        self.webLogin(username: username!)
    }
    
     @IBAction func saveButtonPress(_ sender: Any) {
        pinConfig()
    }
    
     @IBAction func finalButtonPress(_ sender: Any) {

        log()
    }
    
     @IBAction func updateButtonPress(_ sender: Any) {
        
        webSignUp(username: self.mobile, password: self._confirmPin.text!)
    }

    //TODO: - Login
    func webLogin(username: String, onCompletion: (() -> Void)? = nil, onError: ((Error?) -> Void)? = nil) {
        
        let req = """
        mobile_no=\(username)
        """
        
        //    let urlString = URL(string: "http://sparkdeath324.pythonanywhere.com/users/get_userinfo/")
        let urlString = URL(string: "http://sparkdeath324.pythonanywhere.com/users/verify_mobile_number/")
        
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        let theRequest = NSMutableURLRequest.init(url: urlString!, cachePolicy: .reloadRevalidatingCacheData, timeoutInterval: 60)
        theRequest.httpMethod = "POST"
        theRequest.httpBody = req.data(using: String.Encoding.utf8, allowLossyConversion: false)
        
        let dataTask = URLSession.shared.dataTask(with: theRequest as URLRequest) { data, response, error in
            if((error) != nil) {
                print(error!.localizedDescription)
            }else { // For Debuging...
                //   let str = NSString(data: data!, encoding:String.Encoding.utf8.rawValue)
                //     print("String is ->",str as Any)
                DispatchQueue.main.async {
                    print("The following Users are available:")
                    OperationQueue.main.addOperation {
                        if (response != nil) {
                            if response?.mimeType == "application/json" {
                                
                                do {
                                    print("Deserializing JSON...")
                                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers)
                                    print(json)
                                    
                                    guard let parseJSON = json as? [String:Any] else {
                                        print("error")
                                        self.errorText.text = "Login Error ! Plz Try Again"
                                        return
                                    }
                                    print(parseJSON["verified"] as Any)
                                    print(parseJSON["verified"] as! Int)
                                    print(parseJSON["verified"] as? String as Any)
                                    
//                                    guard let Veri = parseJSON["verified"] as? String,
//                                        Veri == "0" else {
//                                            self.stackView.isHidden = true
//                                            self.passStackView.isHidden = false
//                                            self.errorText.text = "New Username"
//                                            print("New Username")
//                                            return
//                                    }
                                    
                                    let ver = parseJSON["verified"] as! Int
                                    if (ver as AnyObject).isEqual(to: 0) {
                                        self.stackView.isHidden = true
                                        self.pinStackView.isHidden = false
                                        self.errorText.text = "New Username"
                                        print("New Username")
                                        return
                                    }
                                    
//                                    guard let usrrValue = parseJSON["mobile_no"] as? String,
//                                        usrrValue != username else {
//
//                                            self.stackView.isHidden = true
//                                            self.pinStackView.isHidden = false
//                                            self.errorText.text = "New Username"
//                                            print("New Username")
//                                            return
//                                    }
                                    
            
//                                    guard let usrValue = parseJSON["mobile_no"] as? String,
//                                        usrValue == username else {
//                                            self.stackView.isHidden = true
//                                            self.pinStackView.isHidden = false
//                                            self.errorText.text = "Exisiting Username"
//                                            print("Exisiting Username")
//                                            return
//                                    }
                                    
                                    
//                                    guard let PinValue = parseJSON["PIN"] as? String,
//                                            PinValue == username else {
//                                                self.stackView.isHidden = true
//                                                self.pinStackView.isHidden = false
//                                              //  self.pinConfig()
//                                                self.errorText.text = "New Username"
//                                      //      _saveButton.perform(Selector:#selector webSignUp(username: username, password: (parseJSON["OTP"] as? String)!))
//                                            DispatchQueue.main.async {
//
//                                        //    self.webSignUp(username: username, password: (parseJSON["OTP"] as? String)!)
//
//                                              print("New Username")
//                                            }
//                                         //   self.errorText.text = "Username Invalid"
//                                            return
//                                    }
                                    
//                                    guard (parseJSON["verified"] as? String) == "1"
//                                             else {
//                                            print("Incorrect Password")
//                                            DispatchQueue.main.async { self.errorText.text = "Login Error! Plz Check Mobile" }
//                                            return
//                                    }
                                    
                                    //                                    guard let stat = parseJSON["status"] as? String,
                                    //                                        stat == "success" else {
                                    //                                            print("Incorrect Password")
                                    //                                            DispatchQueue.main.async { self.errorText.text = "Login Error ! Plz Try Again" }
                                    //                                            return
                                    //                                    }
                                    
                                    DispatchQueue.main.async(execute: { () -> Void in
                                            //      self.presentMainView()
                                        self.stackView.isHidden = true
                                        self.passStackView.isHidden = false
                                    //    self.log()
                                        print("Password")
                                        onCompletion?()
                                    })
                                    
                                } catch {
                                    print("Error Deserializing JSON: \(error)")
                                    self.errorText.text = "Login Error ! Plz Try Again"
                                }
                                
                                print("Loging In..")
                                UIApplication.shared.isNetworkActivityIndicatorVisible = false
                                //     self.modalView.hideActivityView()
                            }
                        } else {
                            print(Error.self)
                        }//else
                    }
                }
                if (self._mobile == nil ) {
                    DispatchQueue.main.async { self.errorText.text = "Invalid Login! Plz Try Again" }
                    return
                }// else {
                print("Authorized")
           //     UIApplication.shared.isNetworkActivityIndicatorVisible = false
            }
        }
        dataTask.resume()
        print("Searching Data...",theRequest)
    }
    
    func presentMainView() {
        DispatchQueue.main.async {
            let storyboard = UIStoryboard(name: "Main", bundle: .main)
            let navViewController = storyboard.instantiateViewController(withIdentifier: "Home") ///as! UINavigationController
            self.present(navViewController, animated: true)
            self._mobile.text = ""
            self._password.text = ""
        }
    }
    
    
    func log(){
        
        self.passStackView.isHidden = false
        let url = URL(string: "http://sparkdeath324.pythonanywhere.com/users/verify_mobile_number/")
        guard url != nil else { return }
        let req = "mobile_no=\(self.mobile)&pin=\(_password.text ?? "N/A")"
        
        let theRequest = NSMutableURLRequest.init(url: url!, cachePolicy: .reloadRevalidatingCacheData, timeoutInterval: 60)
        theRequest.httpMethod = "POST"
        theRequest.httpBody = req.data(using: String.Encoding.utf8, allowLossyConversion: false)
        
        URLSession.shared.dataTask(with: theRequest as URLRequest) { data, urlResponse, error in
            guard let data = data, error == nil, urlResponse != nil else {
                print("Error while Fetching data...")
                return
            }
            
            do {
                print("Deserializing JSON...")
                if  (try JSONSerialization.jsonObject(with: data) as? [String: Any]) != nil {
                    
                    let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers)
                    print(json)
                    guard let parseJSON = json as? [String:Any],
                        self._password.text == (parseJSON["PIN"] as! String)
                    else {
                        print("error")
                        self.errorText.text = "Login Error ! Plz Try Again"
                        return
                    }
                 
                   // print(data)
                    self.presentMainView()
                }
            } catch {
                print("Error Deserializing JSON: \(error)")
            }
            }.resume()
    }
    
    
    func pinConfig(){
        let url = URL(string: "http://sparkdeath324.pythonanywhere.com/users/get_userinfo/")
        guard url != nil else { return }
        let req = "mobile_no=\(self.mobile)&pin=\(self._confirmPin.text ?? "N/A")"
        
        let theRequest = NSMutableURLRequest.init(url: url!, cachePolicy: .reloadRevalidatingCacheData, timeoutInterval: 60)
        theRequest.httpMethod = "POST"
        theRequest.httpBody = req.data(using: String.Encoding.utf8, allowLossyConversion: false)
        
        URLSession.shared.dataTask(with: theRequest as URLRequest) { data, urlResponse, error in
            guard let data = data, error == nil, urlResponse != nil else {
                print("Error while Fetching data...")
                return
            }
             self.pinStackView.isHidden = true
            
            if self._newPin.text == self._confirmPin.text {
                
                self.profileStackView.isHidden = false
            } else {
                 self.pinStackView.isHidden = false
                self.errorText.text = "PIN Don't Match"
                return
            }
            
            do {
                print("Deserializing JSON...")
                if  (try JSONSerialization.jsonObject(with: data) as? [String: Any]) != nil {
                    
                   
               //     self.webSignUp(username: self.mobile, password: self._confirmPin.text!)
                    
                }
            } catch {
                print("Error Deserializing JSON: \(error)")
            }
            
            }.resume()
    }
    
    
    //TODO: - Login
    func webSignUp(username: String, password: String, onCompletion: (() -> Void)? = nil, onError: ((Error?) -> Void)? = nil) {
        
        pinStackView.isHidden = true
        profileStackView.isHidden = false
        
        let req = """
        first_name=\(self._first.text  ?? "N/A")&last_name=\(self._last.text  ?? "N/A")&pin=\(self._confirmPin.text  ?? "N/A")&dob=\("08-08-2018")&gender=\("Male")&push_id=\("8867")&mobile_no=\(self.mobile)&verified=\("1")&email=\(self._email.text  ?? "N/A")&login_type=\("Partner")
        """
        
        //    let urlString = URL(string: "http://sparkdeath324.pythonanywhere.com/users/get_userinfo/")
        let urlString = URL(string: "http://sparkdeath324.pythonanywhere.com/users/update_userinfo/")
        
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        let theRequest = NSMutableURLRequest.init(url: urlString!, cachePolicy: .reloadRevalidatingCacheData, timeoutInterval: 60)
        //    theRequest.addValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        //    theRequest.addValue(String(soapMessage.count), forHTTPHeaderField: "Content-Length")
        theRequest.httpMethod = "POST"
        theRequest.httpBody = req.data(using: String.Encoding.utf8, allowLossyConversion: false)
        
        let dataTask = URLSession.shared.dataTask(with: theRequest as URLRequest) { data, response, error in
            if((error) != nil) {
                print(error!.localizedDescription)
            }else { // For Debuging...
                //   let str = NSString(data: data!, encoding:String.Encoding.utf8.rawValue)
                //     print("String is ->",str as Any)
                DispatchQueue.main.async {
                    print("The following Users are available:")
                    OperationQueue.main.addOperation {
                        if (response != nil) {
                            if response?.mimeType == "application/json" {
                                
                                do {
                                    print("Deserializing JSON...")
                                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers)
                                    print(json)
                                    guard let parseJSON = json as? [String:Any] else {
                                        print("error")
                                        self.errorText.text = "Login Error ! Plz Try Again"
                                        return
                                    }
                                    self.presentMainView()
                                    print(parseJSON["first_name"] as Any)
                                    //                                    guard let usernameValue = parseJSON["mobile_no"] as? String,
                                    //                                        usernameValue == username else {
                                    //                                            DispatchQueue.main.async {  print("Username Invalid") }
                                    //                                            self.errorText.text = "Username Invalid"
                                    //                                            return
                                    //                                    }
                                    guard let passwordValue = parseJSON["PIN"] as? String,
                                        passwordValue == password else {
                                            print("Incorrect Password")
                                            DispatchQueue.main.async { self.errorText.text = "Login Error ! \n Plz Check Mobile No. or Pin" }
                                            return
                                    }
                                    
                                    //                                    guard let stat = parseJSON["status"] as? String,
                                    //                                        stat == "success" else {
                                    //                                            print("Incorrect Password")
                                    //                                            DispatchQueue.main.async { self.errorText.text = "Login Error ! Plz Try Again" }
                                    //                                            return
                                    //                                    }
                                    
                                    DispatchQueue.main.async(execute: { () -> Void in
                                  //      self.presentMainView()
                                        onCompletion?()
                                    })
                                    
                                } catch {
                                    print("Error Deserializing JSON: \(error)")
                                    self.errorText.text = "Login Error ! Plz Try Again"
                                }
                                
                                print("Loging In..")
                                UIApplication.shared.isNetworkActivityIndicatorVisible = false
                            }
                        } else {
                            print(Error.self)
                        }//else
                    }
                }
                if (self._mobile == nil) {
                    DispatchQueue.main.async { self.errorText.text = "Invalid Login! Plz Try Again" }
                    return
                }// else {
                print("Authorized")
          //      UIApplication.shared.isNetworkActivityIndicatorVisible = false
            }
        }
        dataTask.resume()
        print("Searching Data...",theRequest)
    }
}
